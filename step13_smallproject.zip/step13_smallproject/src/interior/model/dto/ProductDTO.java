package interior.model.dto;

public class ProductDTO {
	private int productPnum;
	private String productPname;
	private int productPrice;
	private String productColor;
	private int productPriority; 
	
	

	public ProductDTO() {}
	
	public int getProductPnum() {
		return productPnum;
	}

	public void setProductPnum(int productPnum) {
		this.productPnum = productPnum;
	}

	public String getProductPname() {
		return productPname;
	}

	public void setProductPname(String productPname) {
		this.productPname = productPname;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductColor() {
		return productColor;
	}

	public void setProductColor(String productColor) {
		this.productColor = productColor;
	}

	public int getProductPriority() {
		return productPriority;
	}

	public void setProductPriority(int productPriority) {
		this.productPriority = productPriority;
	}
	
	


	public ProductDTO(int productPnum, String productPname, int productPrice, String productColor,
			int productPriority) {
		super();
		this.productPnum = productPnum;
		this.productPname = productPname;
		this.productPrice = productPrice;
		this.productColor = productColor;
		this.productPriority = productPriority;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("1. ��ǰ ���� : ");
		builder.append(productPnum);
		builder.append("2. ��ǰ �� : ");
		builder.append(productPname);
		builder.append("3. ��ǰ ����  : ");
		builder.append(productPrice);
		builder.append("4. ��ǰ ����  : ");
		builder.append(productColor);
		builder.append("5. ��ǰ �켱���� : ");
		builder.append(productPriority);
		return builder.toString();
	}
	
}
